"""Model registry.

To add a new model: implement a :class:`~simulator.models.base.StochasticModel`
subclass and add it to :data:`MODEL_REGISTRY`. The engine and UI discover
models exclusively through this mapping (open/closed principle).
"""

from __future__ import annotations

from typing import Type

from simulator.models.base import StochasticModel
from simulator.models.geometric_brownian import GeometricBrownianMotion
from simulator.models.heston import HestonModel
from simulator.models.historical_bootstrap import HistoricalBootstrap
from simulator.models.jump_diffusion import MertonJumpDiffusion
from simulator.models.mean_reversion import OrnsteinUhlenbeck
from simulator.models.variance_gamma import VarianceGamma

MODEL_REGISTRY: dict[str, Type[StochasticModel]] = {
    GeometricBrownianMotion.name: GeometricBrownianMotion,
    MertonJumpDiffusion.name: MertonJumpDiffusion,
    HestonModel.name: HestonModel,
    OrnsteinUhlenbeck.name: OrnsteinUhlenbeck,
    VarianceGamma.name: VarianceGamma,
    HistoricalBootstrap.name: HistoricalBootstrap,
}


def create_model(cfg) -> StochasticModel:
    try:
        return MODEL_REGISTRY[cfg.model](cfg)
    except KeyError as exc:
        raise ValueError(f"Unknown model '{cfg.model}'") from exc


__all__ = ["MODEL_REGISTRY", "create_model", "StochasticModel"]
